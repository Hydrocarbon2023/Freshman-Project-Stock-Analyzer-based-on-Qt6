#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "sortthread.h"
#include "indexthread.h"
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <QFileDialog>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    sortThread = new SortThread(this);
    indexThread = new IndexThread(this);
    connect(ui->sortButton, &QPushButton::clicked, this, &MainWindow::on_sortButtonClicked);
    connect(sortThread, &SortThread::complete, this, &MainWindow::on_sortingComplete);
    connect(ui->browseButton, &QPushButton::clicked, this, &MainWindow::on_browseButtonClicked);
    connect(sortThread->exSort, &ExternalSort::updateSortingState, this, &MainWindow::on_sortingStateUpdated);
    connect(indexThread, &IndexThread::complete, this, &MainWindow::on_indexComplete);
    connect(indexThread, &IndexThread::updateCurrentState, this, &MainWindow::on_sortingStateUpdated);
    connect(ui->candleButton, &QPushButton::clicked, this, &MainWindow::on_candleButtonClicked);
    isGoingToSort = true;
    ui->candleButton->setEnabled(false);
    ui->candleButton->setStyleSheet("QPushButton { color : grey; }");
    ui->heatButton->setEnabled(false);
    ui->heatButton->setStyleSheet("QPushButton { color : grey; }");
    ui->predictButton->setEnabled(false);
    ui->predictButton->setStyleSheet("QPushButton { color : grey; }");
}

MainWindow::~MainWindow() {
    delete ui;
    if (sortThread->isRunning()) {
        sortThread->quit();
        sortThread->wait();
    }
    delete sortThread;
    if (indexThread->isRunning()) {
        indexThread->quit();
        indexThread->wait();
    }
    delete indexThread;
}

void MainWindow::on_sortButtonClicked() {
    if (isGoingToSort) {
        QString defaultLine = "请选择文件(*.csv):";
        QString lineText = ui->inputPathLine->text();
        if (lineText != defaultLine) {
            inputPath = lineText.toStdString();
            std::filesystem::path iPath(inputPath);
            outputPath = iPath.parent_path().string() + "/output.txt";
        }
        if (inputPath.empty() || outputPath.empty()) {
            QMessageBox::warning(this, "注意", "请先选择路径");
            return;
        }
        sortThread->setInputPath(inputPath);
        sortThread->setOutputPath(outputPath);
        sortThread->start();
    }
    else {
        std::filesystem::path iPath(outputPath);
        indexPath = iPath.parent_path().string() + "/index.txt";
        indexThread->setInPath(outputPath);
        indexThread->setIndexPath(indexPath);
        indexThread->start();
    }
}

void MainWindow::on_sortingComplete() {
    QMessageBox::information(this, "报告", "排序已完成。");
    ui->sortButton->setText("创建索引");
    isGoingToSort = false;
}

void MainWindow::on_browseButtonClicked() {
    QString inputPath = QFileDialog::getOpenFileName(this, tr("选择文件"), QDir::homePath(), tr("CSV files (*.csv)"));
    if (!inputPath.isEmpty())
        ui->inputPathLine->setText(inputPath);
}

void MainWindow::on_sortingStateUpdated(const QString &message) {
    ui->inputPathLine->setText(message);
}

void MainWindow::on_indexComplete() {
    QMessageBox::information(this, "报告", "索引已生成。");
    loadIndex(indexPath);
    ui->sortButton->setText("一键排序");
    isGoingToSort = true;
    ui->candleButton->setEnabled(true);
    ui->candleButton->setStyleSheet("");
    ui->candleButton->setEnabled(true);
    ui->candleButton->setStyleSheet("");
    ui->candleButton->setEnabled(true);
    ui->candleButton->setStyleSheet("");
}

void MainWindow::on_candleButtonClicked() {
    std::string code = ui->codeLine->text().toStdString();
    std::string month = ui->timeLine->text().toStdString();
    if (code.empty() || month.empty())
        throw std::runtime_error("请输入有效数据。");

    ui->custom_plot->clearItems();
    ui->custom_plot->clearGraphs();
    ui->custom_plot->clearPlottables();
    ui->custom_plot->plotLayout()->clear();
    ui->custom_plot->replot();
    QCPAxisRect *cs_axis_rect = new QCPAxisRect(ui->custom_plot), *vol_axis_rect = new QCPAxisRect(ui->custom_plot);
    ui->custom_plot->plotLayout()->addElement(0, 0, cs_axis_rect);
    ui->custom_plot->plotLayout()->addElement(1, 0, vol_axis_rect);
    vol_axis_rect->setMaximumSize(QSize(QWIDGETSIZE_MAX, 100));
    for(QCPAxis *axis : cs_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }
    for(QCPAxis *axis : vol_axis_rect->axes()) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }
    QCPFinancial *candle_stick = new QCPFinancial(cs_axis_rect->axis(QCPAxis::atBottom), cs_axis_rect->axis(QCPAxis::atLeft));
    QCPBars *volume_pos = new QCPBars(vol_axis_rect->axis(QCPAxis::atBottom), vol_axis_rect->axis(QCPAxis::atLeft));
    QCPBars *volume_neg = new QCPBars(vol_axis_rect->axis(QCPAxis::atBottom), vol_axis_rect->axis(QCPAxis::atLeft));
    QCPDataContainer<QCPFinancialData> QCP_financial_data;
    QSharedPointer<QCPAxisTickerText> text_ticker(new QCPAxisTickerText);

    long long offset = dict[code + ".SZ_" + month];
    if (offset == std::streampos(-1)) {
        QMessageBox::warning(this, "注意", "未找到当月数据TT");
        candle_stick->~QCPFinancial();
        volume_pos->~QCPBars();
        volume_neg->~QCPBars();
        return;
    }
    std::ifstream inputFile;
    inputFile.open(outputPath, std::ios::binary);
    if (!inputFile.is_open())
        throw std::runtime_error("源文件打开失败TT");
    inputFile.seekg(offset);
    std::string line;
    StockData data;
    if (offset == 0)
        std::getline(inputFile, line);
    while (std::getline(inputFile, line)) {
        QCPFinancialData fData;
        QCPBarsData bData;
        data = lineToData(line);
        fData.key = std::stoi(data.trade_date.substr(6, 2));
        fData.open = data.open;
        fData.high = data.high;
        fData.low = data.low;
        fData.close = data.close;
        bData.key = fData.key;
        bData.value = data.volume;
        if (data.trade_date.substr(0, 6) != month)
            break;
        double change = data.change;

        QCP_financial_data.add(fData);
        (change < 0 ? volume_neg : volume_pos)->addData(fData.key, bData.value);
        text_ticker->addTick(fData.key, QString::fromStdString(std::to_string(fData.key)));
    }
    inputFile.close();

    candle_stick->setName("日K");
    candle_stick->setChartStyle(QCPFinancial::csCandlestick);
    candle_stick->setBrushPositive(QColor("#EC0000"));
    candle_stick->setBrushNegative(QColor("#00DA3C"));
    candle_stick->setPenPositive(QColor("#8A0000"));
    candle_stick->setPenNegative(QColor("#008F28"));
    candle_stick->data()->set(QCP_financial_data);
    volume_pos->setPen(Qt::NoPen);
    volume_pos->setBrush(QColor("#EC0000"));
    volume_neg->setPen(Qt::NoPen);
    volume_neg->setBrush(QColor("#00DA3C"));
    connect(cs_axis_rect->axis(QCPAxis::atBottom), SIGNAL(rangeChanged(QCPRange)), vol_axis_rect->axis(QCPAxis::atBottom), SLOT(setRange(QCPRange)));
    connect(vol_axis_rect->axis(QCPAxis::atBottom), SIGNAL(rangeChanged(QCPRange)), cs_axis_rect->axis(QCPAxis::atBottom), SLOT(setRange(QCPRange)));
    vol_axis_rect->axis(QCPAxis::atBottom)->setTicker(text_ticker);
    vol_axis_rect->axis(QCPAxis::atBottom)->setTickLabelRotation(15);
    cs_axis_rect->axis(QCPAxis::atBottom)->setBasePen(Qt::NoPen);
    cs_axis_rect->axis(QCPAxis::atBottom)->setTickLabels(false);
    cs_axis_rect->axis(QCPAxis::atBottom)->setTicks(false);
    ui->custom_plot->rescaleAxes();
    cs_axis_rect->axis(QCPAxis::atBottom)->setRange(0, 32);
    QCPMarginGroup *group = new QCPMarginGroup(ui->custom_plot);
    ui->custom_plot->axisRect()->setMarginGroup(QCP::msLeft|QCP::msRight, group);
    cs_axis_rect->setMarginGroup(QCP::msLeft|QCP::msRight, group);
    vol_axis_rect->setMarginGroup(QCP::msLeft|QCP::msRight, group);
    ui->custom_plot->replot();

    QMessageBox::information(this, "报告", "图像绘制完成。");
}

void MainWindow::loadIndex(const std::string &path) {
    dict.clear();
    std::ifstream indexFile(path);
    std::string line;
    if (!indexFile.is_open())
        throw std::runtime_error("打开索引失败TT");
    while (std::getline(indexFile, line)) {
        std::istringstream iss(line);
        std::string symbolCode, tradeMonth;
        std::string tmpIndex;
        if (std::getline(iss, symbolCode, ',') && (std::getline(iss, tradeMonth, ',')) && (iss >> tmpIndex)) {
            std::string key = symbolCode + "_" + tradeMonth;
            long long index = std::stoll(tmpIndex);
            dict[key] = index;
        }
    }
    indexFile.close();
}

StockData MainWindow::lineToData(const std::string &line) {
    StockData data;
    std::istringstream in(line);
    std::string field;
    std::vector<std::string> fields;
    while (std::getline(in, field, ','))
        fields.push_back(field);
    int s = fields.size();
    if (s != 11) {
        QMessageBox::warning(this, "警告", "不好，数据格式有误");
        return data;
    }
    data.symbol_code = fields[0];
    data.trade_date = fields[1];
    data.open = std::stod(fields[2]);
    data.high = std::stod(fields[3]);
    data.low = std::stod(fields[4]);
    data.close = std::stod(fields[5]);
    data.pre_close = std::stod(fields[6]);
    data.change = std::stod(fields[7]);
    data.percent_change = std::stod(fields[8]);
    data.volume = std::stod(fields[9]);
    data.turnover = std::stod(fields[10]);
    return data;
}
